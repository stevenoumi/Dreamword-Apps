import React from 'react';
import CheckoutForm from '../components/CheckOut';

function PayementPage() {

  return (
    <>
     <CheckoutForm/>
    </>
   
  );
}

export default PayementPage;
